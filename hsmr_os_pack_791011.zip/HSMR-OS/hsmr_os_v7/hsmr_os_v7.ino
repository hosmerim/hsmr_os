#include <WiFi.h>
#include <WebServer.h>
#include <SPIFFS.h>

WebServer server(80);

// --- CSS ve HTML (Fixli Görsel Arayüz) ---
const char INDEX_HTML[] PROGMEM = R"=====(
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>HSMR OS v7.0 - Bug Free</title>
    <style>
        body { background: #300a24; height: 100vh; margin: 0; font-family: 'Ubuntu Mono', monospace; overflow: hidden; color: white; user-select: none; }
        .desktop { position: absolute; top: 20px; left: 20px; display: flex; flex-direction: column; gap: 20px; z-index: 1; }
        .icon { width: 80px; text-align: center; cursor: pointer; padding: 10px; border-radius: 12px; transition: 0.2s; }
        .icon:hover { background: rgba(255,255,255,0.15); transform: scale(1.1); }
        .icon span { font-size: 45px; display: block; }
        
        .window { position: absolute; top: 80px; left: 180px; width: 660px; background: #2c001e; border: 1px solid #5e2750; border-radius: 8px; display: none; flex-direction: column; box-shadow: 0 15px 50px rgba(0,0,0,0.8); z-index: 10; }
        .header { background: #4a0a32; padding: 12px; display: flex; justify-content: space-between; font-size: 14px; cursor: move; border-radius: 8px 8px 0 0; }
        .close-btn { color: white; border: none; background: #ef3340; cursor: pointer; border-radius: 50%; width: 18px; height: 18px; font-size: 10px; line-height: 18px; text-align: center; }
        
        #term-out { height: 380px; overflow-y: auto; padding: 15px; white-space: pre; font-size: 14px; color: #dfdbd2; background: #1a0012; scroll-behavior: smooth; }
        .input-line { padding: 12px; border-top: 1px solid #4a0a32; display: flex; background: #2c001e; }
        .prompt { color: #87ff5f; margin-right: 8px; font-weight: bold; }
        input { background: transparent; border: none; color: white; width: 100%; outline: none; font-family: inherit; font-size: 15px; }
        
        #panic { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #b01a5a; z-index: 9999; text-align: center; flex-direction: column; justify-content: center; }
    </style>
</head>
<body>
    <div class="desktop">
        <div class="icon" onclick="openWin('term-win')"><span>📟</span><small>Terminal</small></div>
        <div class="icon" onclick="openWin('game-win')"><span>🏎️</span><small>Drift</small></div>
    </div>

    <div id="term-win" class="window">
        <div class="header" onmousedown="dragStart(event, 'term-win')"><span>📟 hosmerim@esp32: ~</span><button class="close-btn" onclick="closeWin('term-win')">X</button></div>
        <div id="term-out">Welcome to HSMR OS v7.0 - Final Bug Fix\nAll terminal commands are now smart-parsed.\nTry 'neofetch' or 'help'.\n</div>
        <div class="input-line"><span class="prompt">hosmerim@esp32:~$</span><input type="text" id="cmd-in" autofocus autocomplete="off"></div>
    </div>

    <div id="game-win" class="window" style="width: 420px;">
        <div class="header" onmousedown="dragStart(event, 'game-win')"><span>🏎️ Drift v1.0</span><button class="close-btn" onclick="closeWin('game-win')">X</button></div>
        <canvas id="game-canvas" width="400" height="300" style="background:#111; margin:10px auto; display:block; border-radius:4px;"></canvas>
    </div>

    <div id="panic"><h1>KERNEL PANIC!</h1><p>System state: DESTROYED</p></div>

    <script>
        let activeWin = null, oX, oY;
        function dragStart(e, id) {
            activeWin = document.getElementById(id);
            document.querySelectorAll('.window').forEach(w => w.style.zIndex = "10");
            activeWin.style.zIndex = "100";
            oX = e.clientX - activeWin.offsetLeft;
            oY = e.clientY - activeWin.offsetTop;
            document.onmousemove = (ev) => {
                if(activeWin) {
                    activeWin.style.left = (ev.clientX - oX) + "px";
                    activeWin.style.top = (ev.clientY - oY) + "px";
                }
            };
            document.onmouseup = () => { activeWin = null; document.onmousemove = null; };
        }

        function openWin(id) { document.getElementById(id).style.display = 'flex'; }
        function closeWin(id) { document.getElementById(id).style.display = 'none'; }

        const inp = document.getElementById('cmd-in');
        const out = document.getElementById('term-out');
        inp.onkeypress = (e) => {
            if (e.key === 'Enter') {
                const val = inp.value.trim();
                out.innerHTML += "\n<b>hosmerim@esp32:~$ " + val + "</b>";
                if(val === 'sudo rm -rf /') document.getElementById('panic').style.display='flex';
                else if(val === 'clear') out.innerHTML = "";
                else {
                    fetch('/terminal?cmd=' + encodeURIComponent(val)).then(r => r.text()).then(d => {
                        out.innerHTML += "\n" + d;
                        out.scrollTop = out.scrollHeight;
                    });
                }
                inp.value = '';
            }
        };

        const canvas = document.getElementById('game-canvas');
        const ctx = canvas.getContext('2d');
        let car = { x: 200, y: 150, angle: 0, speed: 0 };
        let keys = {};
        window.onkeydown = e => keys[e.code] = true;
        window.onkeyup = e => keys[e.code] = false;
        function loop() {
            if(keys['ArrowUp']) car.speed=2.2; else if(keys['ArrowDown']) car.speed=-2.2; else car.speed*=0.95;
            if(keys['ArrowLeft']) car.angle-=0.07; if(keys['ArrowRight']) car.angle+=0.07;
            car.x += Math.cos(car.angle)*car.speed; car.y += Math.sin(car.angle)*car.speed;
            if(car.x>400) car.x=0; if(car.x<0) car.x=400; if(car.y>300) car.y=0; if(car.y<0) car.y=300;
            ctx.fillStyle='#111'; ctx.fillRect(0,0,400,300);
            ctx.save(); ctx.translate(car.x,car.y); ctx.rotate(car.angle);
            ctx.fillStyle='#e95420'; ctx.fillRect(-12,-6,24,12); ctx.restore();
            requestAnimationFrame(loop);
        }
        loop();
    </script>
</body>
</html>
)=====";

// --- C++ Komut İşleme (Tüm Buglar Temizlendi) ---
void handleTerminal() {
    String raw = server.arg("cmd");
    raw.trim(); // Fazladan boşlukları temizle
    
    int spaceIndex = raw.indexOf(' ');
    String cmd = (spaceIndex == -1) ? raw : raw.substring(0, spaceIndex);
    String arg = (spaceIndex == -1) ? "" : raw.substring(spaceIndex + 1);
    
    String res = "";

    if (cmd == "ls") {
        File root = SPIFFS.open("/");
        File file = root.openNextFile();
        while(file) {
            res += "[FILE] " + String(file.name()) + " (" + String(file.size()) + " B)\n";
            file = root.openNextFile();
        }
        if(res == "") res = "Dizin bos.";
    } 
    else if (cmd == "neofetch") {
        res = "  _    _  _____  __  __  ____  \n"
              " | |  | |/ ____||  \\/  ||  _ \\ \n"
              " | |__| | (___  | \\  / || |_) |\n"
              " |  __  |\\___ \\ | |\\/| ||  _ < \n"
              " | |  | |____) || |  | || |_) |\n"
              " |_|  |_|_____/ |_|  |_||____/ \n"
              "------------------------------\n"
              "OS: HSMR OS v7.0.0 (FINAL)\n"
              "Uptime: " + String(millis()/60000) + " mins\n"
              "Disk: SPIFFS Persistent Storage";
    }
    else if (cmd == "nano") {
        int contentPos = arg.indexOf(' ');
        if(contentPos != -1) {
            String fileName = arg.substring(0, contentPos);
            String content = arg.substring(contentPos + 1);
            File f = SPIFFS.open("/" + fileName, "w");
            if(f) { f.print(content); f.close(); res = fileName + " kaydedildi."; }
        } else { res = "Hata! Kullanim: nano [dosya] [icerik]"; }
    }
    else if (cmd == "cat") {
        if(SPIFFS.exists("/" + arg)) {
            File f = SPIFFS.open("/" + arg, "r");
            while(f.available()) res += (char)f.read();
            f.close();
        } else res = "Hata: Dosya bulunamadi.";
    }
    else if (cmd == "rm") {
        if(SPIFFS.remove("/" + arg)) res = arg + " silindi.";
        else res = "Hata: Silinemedi.";
    }
    else if (cmd == "help") {
        res = "Komutlar: ls, neofetch, nano [ad] [icerik], cat [ad], rm [ad], clear, reboot";
    }
    else if (cmd == "reboot") {
        server.send(200, "text/plain", "Gorusuruz usta...");
        delay(1000); ESP.restart();
    }
    else {
        res = "bash: " + cmd + ": komut bulunamadi.";
    }
    server.send(200, "text/plain", res);
}

void setup() {
    Serial.begin(115200);
    if(!SPIFFS.begin(true)) Serial.println("SPIFFS Hata!");

    WiFi.softAP("HSMR_OS_Final", "hosmerim123");
    server.on("/", []() { server.send(200, "text/html", INDEX_HTML); });
    server.on("/terminal", handleTerminal);
    server.begin();
}

void loop() { server.handleClient(); }

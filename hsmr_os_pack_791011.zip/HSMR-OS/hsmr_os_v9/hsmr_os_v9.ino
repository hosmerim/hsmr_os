#include <WiFi.h>
#include <WebServer.h>
#include <SPIFFS.h>

// =============================================
// YAPILANDIRMA
// =============================================
const char* WIFI_SSID     = "HSMR-OS";
const char* WIFI_PASSWORD = "hosmerim123";

WebServer server(80);

// =============================================
// KULLANICI SİSTEMİ
// Kullanıcılar SPIFFS'te /users/kullanici.txt
// olarak saklanır. İçerik: "sifre_hash"
// Basit hash: karakterlerin toplamı (mod 9999)
// =============================================
struct Kullanici {
    String ad;
    String sifre;
};

// Varsayılan admin kullanıcısı (ilk kurulumda oluşturulur)
const char* ADMIN_AD     = "hosmerim";
const char* ADMIN_SIFRE  = "1234";

// Aktif oturum token'ları (RAM'da tutulur, reboot'ta sıfırlanır)
// token -> kullaniciAdi
#define MAX_SESSION 8
String sessionTokens[MAX_SESSION];
String sessionUsers[MAX_SESSION];
int    sessionCount = 0;

String oturum_olustur(String kullanici) {
    // Basit token: millis + kullanici adı karması
    String token = String(millis()) + String(random(1000, 9999));
    if (sessionCount < MAX_SESSION) {
        sessionTokens[sessionCount] = token;
        sessionUsers[sessionCount]  = kullanici;
        sessionCount++;
    }
    return token;
}

String token_kullanici(String token) {
    for (int i = 0; i < sessionCount; i++) {
        if (sessionTokens[i] == token) return sessionUsers[i];
    }
    return "";
}

void oturum_kapat(String token) {
    for (int i = 0; i < sessionCount; i++) {
        if (sessionTokens[i] == token) {
            // Kaydır
            for (int j = i; j < sessionCount - 1; j++) {
                sessionTokens[j] = sessionTokens[j+1];
                sessionUsers[j]  = sessionUsers[j+1];
            }
            sessionCount--;
            return;
        }
    }
}

// Kullanıcıyı SPIFFS'te kaydet
void kullanici_kaydet(String ad, String sifre) {
    File f = SPIFFS.open("/users/" + ad + ".usr", "w");
    if (f) { f.print(sifre); f.close(); }
}

// Kullanıcı doğrula
bool kullanici_dogrula(String ad, String sifre) {
    String path = "/users/" + ad + ".usr";
    if (!SPIFFS.exists(path)) return false;
    File f = SPIFFS.open(path, "r");
    String kayitliSifre = "";
    while (f.available()) kayitliSifre += (char)f.read();
    f.close();
    return kayitliSifre == sifre;
}

// =============================================
// HTML ARAYÜZÜ
// =============================================
const char INDEX_HTML[] PROGMEM = R"=====(
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>HSMR OS v9.0</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        /* ---- GİRİŞ EKRANI ---- */
        #login-screen {
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background: #1a0012;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            font-family: 'Ubuntu Mono', monospace;
            color: white;
        }
        #login-screen h1 { color: #87ff5f; font-size: 28px; margin-bottom: 6px; letter-spacing: 3px; }
        #login-screen p  { color: #aaa; font-size: 12px; margin-bottom: 28px; }
        .login-box {
            background: #2c001e;
            border: 1px solid #5e2750;
            border-radius: 12px;
            padding: 28px 32px;
            width: 320px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .login-box input {
            background: #1a0012;
            border: 1px solid #5e2750;
            border-radius: 6px;
            color: white;
            padding: 10px 12px;
            font-family: inherit;
            font-size: 14px;
            outline: none;
            width: 100%;
        }
        .login-box input:focus { border-color: #87ff5f; }
        .login-box button {
            background: #87ff5f;
            border: none;
            border-radius: 6px;
            color: #1a0012;
            padding: 10px;
            font-family: inherit;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
        }
        .login-box button:hover { background: #aaffaa; }
        .login-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 4px;
        }
        .login-tab {
            flex: 1;
            padding: 7px;
            text-align: center;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            border: 1px solid #5e2750;
            color: #aaa;
            transition: 0.2s;
        }
        .login-tab.active { background: #4a0a32; color: white; border-color: #87ff5f; }
        #login-msg { font-size: 12px; min-height: 16px; text-align: center; }
        #login-msg.ok  { color: #87ff5f; }
        #login-msg.err { color: #ef9090; }

        /* ---- MASAÜSTÜ ---- */
        body {
            background: #300a24;
            height: 100vh;
            overflow: hidden;
            color: white;
            font-family: 'Ubuntu Mono', monospace;
            user-select: none;
        }

        /* Üst bar */
        #topbar {
            position: fixed; top: 0; left: 0; right: 0;
            height: 28px;
            background: #1a0012;
            border-bottom: 1px solid #5e2750;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 14px;
            font-size: 12px;
            z-index: 500;
        }
        #topbar-left  { color: #87ff5f; font-weight: bold; }
        #topbar-right { color: #aaa; display: flex; gap: 14px; align-items: center; }
        #topbar-user  { color: white; }
        #logout-btn {
            background: none; border: 1px solid #5e2750;
            color: #ef9090; border-radius: 4px;
            padding: 1px 8px; cursor: pointer;
            font-family: inherit; font-size: 11px;
        }
        #logout-btn:hover { background: #3a0020; }

        .desktop {
            position: absolute;
            top: 48px; left: 20px;
            display: flex;
            flex-direction: column;
            gap: 16px;
            z-index: 1;
        }
        .icon {
            width: 76px;
            text-align: center;
            cursor: pointer;
            padding: 8px;
            border-radius: 10px;
            transition: 0.2s;
        }
        .icon:hover { background: rgba(255,255,255,0.12); transform: scale(1.08); }
        .icon span  { font-size: 38px; display: block; }
        .icon small { font-size: 11px; color: #ddd; }

        /* ---- PENCERELER ---- */
        .window {
            position: absolute;
            top: 60px; left: 180px;
            width: 720px;
            background: #2c001e;
            border: 1px solid #5e2750;
            border-radius: 8px;
            display: none;
            flex-direction: column;
            box-shadow: 0 15px 50px rgba(0,0,0,0.85);
            z-index: 10;
        }
        .header {
            background: #4a0a32;
            padding: 10px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            cursor: move;
            border-radius: 8px 8px 0 0;
        }
        .close-btn {
            color: white; border: none;
            background: #ef3340;
            cursor: pointer; border-radius: 50%;
            width: 18px; height: 18px;
            font-size: 10px; line-height: 18px;
            text-align: center; flex-shrink: 0;
        }

        /* ---- TERMİNAL ---- */
        #term-out {
            height: 400px;
            overflow-y: auto;
            padding: 14px;
            font-size: 13px;
            color: #dfdbd2;
            background: #1a0012;
            scroll-behavior: smooth;
            white-space: pre-wrap;
            word-break: break-word;
        }
        .input-line {
            padding: 9px 14px;
            border-top: 1px solid #4a0a32;
            display: flex;
            align-items: center;
            background: #2c001e;
        }
        #prompt-label {
            color: #87ff5f;
            font-weight: bold;
            white-space: nowrap;
            font-size: 13px;
            margin-right: 6px;
        }
        #cmd-in {
            background: transparent; border: none;
            color: white; width: 100%; outline: none;
            font-family: inherit; font-size: 13px;
        }

        /* ---- DOSYA YÖNETİCİSİ ---- */
        #fm-body { display: flex; height: 380px; }
        #fm-list {
            flex: 1; overflow-y: auto;
            padding: 8px;
            background: #1a0012;
            border-right: 1px solid #4a0a32;
        }
        .fm-item {
            padding: 7px 10px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .fm-item:hover { background: rgba(255,255,255,0.07); }
        .fm-item.selected { background: rgba(135,255,95,0.12); }
        .fm-item-name { flex: 1; }
        .fm-item-size { color: #888; font-size: 11px; flex-shrink: 0; margin-left: 10px; }
        .fm-actions {
            width: 195px; padding: 14px;
            display: flex; flex-direction: column; gap: 9px;
            background: #2c001e;
        }
        .fm-sel-label { font-size: 11px; color: #888; }
        .fm-sel-name  { font-size: 12px; color: white; word-break: break-all; min-height: 14px; }
        .fm-btn {
            padding: 8px 10px;
            background: #4a0a32; border: 1px solid #7a1a52;
            color: white; border-radius: 6px;
            cursor: pointer; font-family: inherit;
            font-size: 12px; text-align: center;
            transition: 0.15s; text-decoration: none;
            display: block;
        }
        .fm-btn:hover   { background: #6a1a42; }
        .fm-btn.danger  { border-color: #ef3340; color: #ef9090; }
        .fm-btn.danger:hover { background: #5a0a1a; }
        #upload-area {
            border: 2px dashed #5e2750;
            border-radius: 8px; padding: 12px;
            text-align: center; font-size: 12px;
            color: #aaa; cursor: pointer; transition: 0.2s;
        }
        #upload-area:hover, #upload-area.drag { border-color: #87ff5f; color: #87ff5f; }
        #file-input { display: none; }
        #fm-status {
            padding: 6px 12px; font-size: 11px;
            color: #87ff5f; background: #1a0012;
            border-top: 1px solid #4a0a32; min-height: 22px;
        }

        /* ---- KERNEL PANIC ---- */
        #panic {
            display: none; position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: #b01a5a; z-index: 99998;
            text-align: center; flex-direction: column;
            justify-content: center; align-items: center;
        }
        #panic h1 { font-size: 44px; }
        #panic p  { font-size: 18px; margin-top: 10px; }
        #panic button {
            margin-top: 24px; padding: 12px 28px;
            font-size: 15px; cursor: pointer;
            background: #2c001e; border: 2px solid white;
            color: white; border-radius: 8px; font-family: inherit;
        }

        /* ---- SCROLLBAR ---- */
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: #1a0012; }
        ::-webkit-scrollbar-thumb { background: #5e2750; border-radius: 3px; }
    </style>
</head>
<body>

<!-- ======== GİRİŞ EKRANI ======== -->
<div id="login-screen">
    <h1>HSMR OS</h1>
    <p>v9.0 — hosmerim@esp32</p>
    <div class="login-box">
        <div class="login-tabs">
            <div class="login-tab active" id="tab-giris"  onclick="loginTab('giris')">Giriş Yap</div>
            <div class="login-tab"        id="tab-kayit"  onclick="loginTab('kayit')">Kayıt Ol</div>
        </div>
        <input type="text"     id="l-user" placeholder="Kullanıcı adı" autocomplete="off">
        <input type="password" id="l-pass" placeholder="Şifre">
        <input type="password" id="l-pass2" placeholder="Şifre tekrar (kayıt için)" style="display:none">
        <button id="l-btn" onclick="loginSubmit()">Giriş Yap</button>
        <div id="login-msg"></div>
    </div>
</div>

<!-- ======== MASAÜSTÜ ======== -->
<!-- Üst bar -->
<div id="topbar">
    <div id="topbar-left">HSMR OS v9.0</div>
    <div id="topbar-right">
        <span id="topbar-clock">--:--:--</span>
        <span id="topbar-user">—</span>
        <button id="logout-btn" onclick="cikisYap()">Çıkış</button>
    </div>
</div>

<div class="desktop">
    <div class="icon" onclick="openWin('term-win')">
        <span>📟</span><small>Terminal</small>
    </div>
    <div class="icon" onclick="openWin('fm-win'); fmRefresh()">
        <span>📁</span><small>Dosyalar</small>
    </div>
    <div class="icon" onclick="openWin('game-win'); startGame()">
        <span>🏎️</span><small>Drift</small>
    </div>
</div>

<!-- ======== TERMİNAL ======== -->
<div id="term-win" class="window">
    <div class="header" onmousedown="dragStart(event,'term-win')">
        <span id="term-title">📟 hosmerim@hsmr-os</span>
        <button class="close-btn" onclick="closeWin('term-win')">X</button>
    </div>
    <div id="term-out"></div>
    <div class="input-line">
        <span id="prompt-label">hosmerim@hsmr-os:~$&nbsp;</span>
        <input type="text" id="cmd-in" autocomplete="off" spellcheck="false">
    </div>
</div>

<!-- ======== DOSYA YÖNETİCİSİ ======== -->
<div id="fm-win" class="window" style="width:560px; top:70px; left:200px;">
    <div class="header" onmousedown="dragStart(event,'fm-win')">
        <span>📁 Dosya Yöneticisi — SPIFFS</span>
        <button class="close-btn" onclick="closeWin('fm-win')">X</button>
    </div>
    <div id="fm-body">
        <div id="fm-list">
            <div style="color:#555;font-size:12px;padding:8px;">Yükleniyor...</div>
        </div>
        <div class="fm-actions">
            <div class="fm-sel-label">Seçili dosya:</div>
            <div class="fm-sel-name" id="fm-sel-name">—</div>
            <button class="fm-btn" onclick="fmDownload()">⬇ İndir (Laptopa)</button>
            <button class="fm-btn danger" onclick="fmDelete()">🗑 Sil</button>
            <hr style="border-color:#4a0a32; margin:2px 0;">
            <div id="upload-area"
                 onclick="document.getElementById('file-input').click()"
                 ondragover="event.preventDefault();this.classList.add('drag')"
                 ondragleave="this.classList.remove('drag')"
                 ondrop="handleDrop(event)">
                ⬆ Dosya Yükle<br><small>Tıkla veya sürükle bırak</small>
            </div>
            <input type="file" id="file-input" onchange="handleFileSelect(event)">
            <button class="fm-btn" onclick="fmRefresh()" style="margin-top:2px;">↻ Yenile</button>
        </div>
    </div>
    <div id="fm-status">Hazır.</div>
</div>

<!-- ======== DRIFT OYUNU ======== -->
<div id="game-win" class="window" style="width:420px;">
    <div class="header" onmousedown="dragStart(event,'game-win')">
        <span>🏎️ Drift v1.0</span>
        <button class="close-btn" onclick="closeWin('game-win')">X</button>
    </div>
    <canvas id="game-canvas" width="400" height="300"
        style="background:#111;margin:10px auto;display:block;border-radius:4px;"></canvas>
</div>

<!-- ======== KERNEL PANIC ======== -->
<div id="panic">
    <h1>KERNEL PANIC</h1>
    <p>System state: DESTROYED</p>
    <p style="font-size:13px;color:#ffcccc;margin-top:8px;">Tetikleyen: <span id="panic-user">?</span></p>
    <button onclick="document.getElementById('panic').style.display='none'">Yeniden Başlat</button>
</div>

<script>
// ================================================
// OTURUM & GİRİŞ SİSTEMİ
// ================================================
let aktifKullanici = "";
let aktifToken = "";

// Sayfa yüklenince localStorage'dan token oku
window.onload = function() {
    const t = localStorage.getItem('hsmr_token');
    const u = localStorage.getItem('hsmr_user');
    if (t && u) {
        aktifToken = t;
        aktifKullanici = u;
        masaustuGoster();
    }
    saatGuncelle();
    setInterval(saatGuncelle, 1000);
};

function saatGuncelle() {
    const now = new Date();
    document.getElementById('topbar-clock').textContent =
        now.toLocaleTimeString('tr-TR');
}

let loginModu = 'giris';
function loginTab(mod) {
    loginModu = mod;
    document.getElementById('tab-giris').classList.toggle('active', mod === 'giris');
    document.getElementById('tab-kayit').classList.toggle('active', mod === 'kayit');
    document.getElementById('l-pass2').style.display = mod === 'kayit' ? 'block' : 'none';
    document.getElementById('l-btn').textContent = mod === 'giris' ? 'Giriş Yap' : 'Kayıt Ol';
    document.getElementById('login-msg').textContent = '';
}

function loginMsg(txt, tip) {
    const el = document.getElementById('login-msg');
    el.textContent = txt;
    el.className = tip;
}

function loginSubmit() {
    const user = document.getElementById('l-user').value.trim();
    const pass = document.getElementById('l-pass').value;
    const pass2 = document.getElementById('l-pass2').value;

    if (!user || !pass) { loginMsg('Kullanıcı adı ve şifre gerekli.', 'err'); return; }
    if (loginModu === 'kayit' && pass !== pass2) { loginMsg('Şifreler eşleşmiyor.', 'err'); return; }
    if (loginModu === 'kayit' && user.length < 3) { loginMsg('Kullanıcı adı en az 3 karakter.', 'err'); return; }

    const endpoint = loginModu === 'giris' ? '/login' : '/register';
    fetch(endpoint, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'user=' + encodeURIComponent(user) + '&pass=' + encodeURIComponent(pass)
    })
    .then(r => r.text())
    .then(d => {
        if (d.startsWith('OK:')) {
            aktifToken = d.substring(3);
            aktifKullanici = user;
            localStorage.setItem('hsmr_token', aktifToken);
            localStorage.setItem('hsmr_user', aktifKullanici);
            masaustuGoster();
        } else {
            loginMsg(d, 'err');
        }
    })
    .catch(() => loginMsg('Sunucuya bağlanılamadı.', 'err'));
}

// Enter ile giriş
document.getElementById('l-pass').addEventListener('keypress', e => { if(e.key==='Enter') loginSubmit(); });
document.getElementById('l-pass2').addEventListener('keypress', e => { if(e.key==='Enter') loginSubmit(); });
document.getElementById('l-user').addEventListener('keypress', e => { if(e.key==='Enter') loginSubmit(); });

function masaustuGoster() {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('topbar-user').textContent = aktifKullanici;
    // Terminal başlığını güncelle
    document.getElementById('term-title').textContent = '📟 ' + aktifKullanici + '@hsmr-os';
    document.getElementById('prompt-label').textContent = aktifKullanici + '@hsmr-os:~$ ';
    // Terminal hoş geldin mesajı
    appendLine('HSMR OS v9.0 — Hosgeldin, ' + aktifKullanici + '!', '#87ff5f');
    appendLine("'help' yazarak komutlara bakabilirsin.");
    appendLine('');
}

function cikisYap() {
    if (!aktifToken) return;
    fetch('/logout', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'token=' + encodeURIComponent(aktifToken)
    });
    localStorage.removeItem('hsmr_token');
    localStorage.removeItem('hsmr_user');
    aktifToken = '';
    aktifKullanici = '';
    // Tüm pencereleri kapat
    document.querySelectorAll('.window').forEach(w => w.style.display = 'none');
    document.getElementById('term-out').innerHTML = '';
    document.getElementById('login-screen').style.display = 'flex';
}


// ================================================
// PENCERE SİSTEMİ
// ================================================
let activeWin = null, offsetX = 0, offsetY = 0;

function dragStart(e, id) {
    activeWin = document.getElementById(id);
    document.querySelectorAll('.window').forEach(w => w.style.zIndex = "10");
    activeWin.style.zIndex = "100";
    offsetX = e.clientX - activeWin.offsetLeft;
    offsetY = e.clientY - activeWin.offsetTop;
    document.onmousemove = ev => {
        if (activeWin) {
            activeWin.style.left = (ev.clientX - offsetX) + 'px';
            activeWin.style.top  = (ev.clientY - offsetY) + 'px';
        }
    };
    document.onmouseup = () => { activeWin = null; document.onmousemove = null; };
}

function openWin(id)  { document.getElementById(id).style.display = 'flex'; }
function closeWin(id) {
    if (id === 'game-win') oyunCalisiyor = false;
    document.getElementById(id).style.display = 'none';
}


// ================================================
// TERMİNAL
// ================================================
const inp = document.getElementById('cmd-in');
const out = document.getElementById('term-out');

// Güvenli satır ekle (XSS yok)
function appendLine(text, color) {
    const d = document.createElement('div');
    d.textContent = text;
    if (color) d.style.color = color;
    out.appendChild(d);
    out.scrollTop = out.scrollHeight;
}

function appendCommand(text) {
    const d = document.createElement('div');
    const b = document.createElement('b');
    b.style.color = '#87ff5f';
    b.textContent = aktifKullanici + '@hsmr-os:~$ ';
    d.appendChild(b);
    d.appendChild(document.createTextNode(text));
    out.appendChild(d);
    out.scrollTop = out.scrollHeight;
}

// Komut geçmişi
let cmdGecmis = [], gecmisIndex = -1;

inp.addEventListener('keydown', e => {
    if (e.key === 'ArrowUp') {
        if (gecmisIndex < cmdGecmis.length - 1) gecmisIndex++;
        inp.value = cmdGecmis[gecmisIndex] || '';
        e.preventDefault();
    }
    if (e.key === 'ArrowDown') {
        if (gecmisIndex > 0) gecmisIndex--;
        else { gecmisIndex = -1; inp.value = ''; }
        inp.value = gecmisIndex >= 0 ? cmdGecmis[gecmisIndex] : '';
        e.preventDefault();
    }
});

inp.addEventListener('keypress', e => {
    if (e.key !== 'Enter') return;
    const val = inp.value.trim();
    inp.value = '';
    gecmisIndex = -1;
    if (val === '') return;

    // Geçmişe ekle
    cmdGecmis.unshift(val);
    if (cmdGecmis.length > 50) cmdGecmis.pop();

    appendCommand(val);

    // Tarayıcıda işlenen komutlar
    if (val === 'sudo rm -rf /') {
        document.getElementById('panic-user').textContent = aktifKullanici;
        document.getElementById('panic').style.display = 'flex';
        return;
    }
    if (val === 'clear') { out.innerHTML = ''; return; }

    // Sunucuya gönder (token ile)
    fetch('/terminal?cmd=' + encodeURIComponent(val) + '&token=' + encodeURIComponent(aktifToken))
        .then(r => r.text())
        .then(d => {
            appendLine(d);
            // Dosya yöneticisini güncelle
            const c = val.split(' ')[0];
            if (['ls','rm','nano'].includes(c)) fmRefresh();
        })
        .catch(() => appendLine('Hata: Sunucuya bağlanılamadı.', '#ef9090'));
});


// ================================================
// DOSYA YÖNETİCİSİ
// ================================================
let fmSecilenDosya = null;

function fmRefresh() {
    const list = document.getElementById('fm-list');
    list.innerHTML = '<div style="color:#555;font-size:12px;padding:8px;">Yükleniyor...</div>';

    fetch('/files?token=' + encodeURIComponent(aktifToken))
        .then(r => r.text())
        .then(raw => {
            list.innerHTML = '';
            let dosyalar;
            try { dosyalar = JSON.parse(raw); } catch(e) { dosyalar = []; }

            if (!dosyalar.length) {
                list.innerHTML = '<div style="color:#555;font-size:12px;padding:8px;">SPIFFS boş.</div>';
                return;
            }

            dosyalar.forEach(f => {
                const item = document.createElement('div');
                item.className = 'fm-item';

                const name = document.createElement('div');
                name.className = 'fm-item-name';
                name.textContent = '📄 ' + f.name;

                const size = document.createElement('div');
                size.className = 'fm-item-size';
                size.textContent = f.size + ' B';

                item.appendChild(name);
                item.appendChild(size);

                item.onclick = () => {
                    document.querySelectorAll('.fm-item').forEach(i => i.classList.remove('selected'));
                    item.classList.add('selected');
                    fmSecilenDosya = f.path;
                    document.getElementById('fm-sel-name').textContent = f.name;
                };
                list.appendChild(item);
            });
            fmSetStatus(dosyalar.length + ' dosya listelendi.');
        })
        .catch(() => fmSetStatus('Liste alınamadı.'));
}

function fmSetStatus(msg) {
    document.getElementById('fm-status').textContent = msg;
}

// Dosyayı laptopa indir
function fmDownload() {
    if (!fmSecilenDosya) { fmSetStatus('Önce bir dosya seçin.'); return; }
    // Yeni sekme / download linki
    const url = '/download?path=' + encodeURIComponent(fmSecilenDosya)
              + '&token=' + encodeURIComponent(aktifToken);
    const a = document.createElement('a');
    a.href = url;
    a.download = fmSecilenDosya.split('/').pop();
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    fmSetStatus('İndirme başlatıldı: ' + fmSecilenDosya.split('/').pop());
}

// Dosyayı sil
function fmDelete() {
    if (!fmSecilenDosya) { fmSetStatus('Önce bir dosya seçin.'); return; }
    const ad = fmSecilenDosya.split('/').pop();
    if (!confirm(ad + ' silinsin mi?')) return;
    fetch('/terminal?cmd=' + encodeURIComponent('rm ' + fmSecilenDosya)
         + '&token=' + encodeURIComponent(aktifToken))
        .then(r => r.text())
        .then(d => {
            fmSetStatus(d);
            fmSecilenDosya = null;
            document.getElementById('fm-sel-name').textContent = '—';
            fmRefresh();
        });
}

function handleFileSelect(e) {
    const f = e.target.files[0];
    if (f) uploadFile(f);
    e.target.value = '';
}

function handleDrop(e) {
    e.preventDefault();
    document.getElementById('upload-area').classList.remove('drag');
    const f = e.dataTransfer.files[0];
    if (f) uploadFile(f);
}

function uploadFile(file) {
    fmSetStatus('Yükleniyor: ' + file.name + ' ...');
    const fd = new FormData();
    fd.append('file', file);
    fd.append('token', aktifToken);
    fetch('/upload', { method: 'POST', body: fd })
        .then(r => r.text())
        .then(d => { fmSetStatus(d); fmRefresh(); })
        .catch(() => fmSetStatus('Yükleme başarısız.'));
}


// ================================================
// DRIFT OYUNU
// ================================================
const ARABA_HIZI       = 2.2;
const DONUS_HIZI       = 0.07;
const SURTUNUM         = 0.95;
const CV_W             = 400;
const CV_H             = 300;

const canvas = document.getElementById('game-canvas');
const ctx    = canvas.getContext('2d');
let araba = { x: 200, y: 150, aci: 0, hiz: 0 };
let tuslar = {};
let oyunCalisiyor = false;

window.addEventListener('keydown', e => tuslar[e.code] = true);
window.addEventListener('keyup',   e => tuslar[e.code] = false);

function oyunDongusu() {
    if (!oyunCalisiyor) return;
    if (tuslar['ArrowUp'])        araba.hiz = ARABA_HIZI;
    else if (tuslar['ArrowDown']) araba.hiz = -ARABA_HIZI;
    else                          araba.hiz *= SURTUNUM;
    if (tuslar['ArrowLeft'])  araba.aci -= DONUS_HIZI;
    if (tuslar['ArrowRight']) araba.aci += DONUS_HIZI;
    araba.x += Math.cos(araba.aci) * araba.hiz;
    araba.y += Math.sin(araba.aci) * araba.hiz;
    if (araba.x > CV_W) araba.x = 0;
    if (araba.x < 0)    araba.x = CV_W;
    if (araba.y > CV_H) araba.y = 0;
    if (araba.y < 0)    araba.y = CV_H;
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, CV_W, CV_H);
    ctx.save();
    ctx.translate(araba.x, araba.y);
    ctx.rotate(araba.aci);
    ctx.fillStyle = '#e95420';
    ctx.fillRect(-12, -6, 24, 12);
    ctx.restore();
    requestAnimationFrame(oyunDongusu);
}

function startGame() {
    if (!oyunCalisiyor) { oyunCalisiyor = true; oyunDongusu(); }
}
</script>
</body>
</html>
)=====";


// ================================================
// TOKEN DOĞRULAMA YARDIMCISI
// ================================================
String tokenKontrol() {
    String token = server.arg("token");
    if (token == "") {
        // POST body'den de dene
        token = server.arg("plain");
    }
    return token_kullanici(token);
}


// ================================================
// /login — POST: user=..&pass=..
// ================================================
void handleLogin() {
    String user = server.arg("user");
    String pass = server.arg("pass");
    user.trim(); pass.trim();

    if (user == "" || pass == "") {
        server.send(200, "text/plain", "Kullanici adi ve sifre gerekli.");
        return;
    }
    if (kullanici_dogrula(user, pass)) {
        String tok = oturum_olustur(user);
        server.send(200, "text/plain", "OK:" + tok);
    } else {
        server.send(200, "text/plain", "Yanlis kullanici adi veya sifre.");
    }
}


// ================================================
// /register — POST: user=..&pass=..
// ================================================
void handleRegister() {
    String user = server.arg("user");
    String pass = server.arg("pass");
    user.trim(); pass.trim();

    if (user.length() < 3) {
        server.send(200, "text/plain", "Kullanici adi en az 3 karakter olmali.");
        return;
    }
    if (pass.length() < 4) {
        server.send(200, "text/plain", "Sifre en az 4 karakter olmali.");
        return;
    }
    // Kullanıcı zaten var mı?
    String path = "/users/" + user + ".usr";
    if (SPIFFS.exists(path)) {
        server.send(200, "text/plain", "Bu kullanici adi zaten alinmis.");
        return;
    }
    kullanici_kaydet(user, pass);
    String tok = oturum_olustur(user);
    server.send(200, "text/plain", "OK:" + tok);
}


// ================================================
// /logout — POST: token=..
// ================================================
void handleLogout() {
    String token = server.arg("token");
    oturum_kapat(token);
    server.send(200, "text/plain", "Cikis yapildi.");
}


// ================================================
// /files — GET: token=..
// Tüm SPIFFS dosyalarını JSON olarak döner
// (users/ klasörü hariç)
// ================================================
void handleFiles() {
    String kullanici = token_kullanici(server.arg("token"));
    if (kullanici == "") { server.send(401, "text/plain", "Yetkisiz."); return; }

    File root = SPIFFS.open("/");
    File f = root.openNextFile();
    String json = "[";
    bool first = true;

    while (f) {
        String nm = String(f.name());
        // /users/ klasörünü gizle
        if (!nm.startsWith("/users/")) {
            if (!first) json += ",";
            // isim: / olmadan
            String shortName = nm;
            if (shortName.startsWith("/")) shortName = shortName.substring(1);
            json += "{\"name\":\"" + shortName + "\",\"path\":\"" + nm + "\",\"size\":" + String(f.size()) + "}";
            first = false;
        }
        f = root.openNextFile();
    }
    json += "]";
    server.send(200, "application/json", json);
}


// ================================================
// /terminal — GET: cmd=..&token=..
// ================================================
void handleTerminal() {
    String kullanici = token_kullanici(server.arg("token"));
    if (kullanici == "") { server.send(401, "text/plain", "Oturum suresi doldu. Lutfen tekrar giris yapin."); return; }

    String ham = server.arg("cmd");
    ham.trim();

    int bosluk = ham.indexOf(' ');
    String cmd = (bosluk == -1) ? ham : ham.substring(0, bosluk);
    String arg = (bosluk == -1) ? "" : ham.substring(bosluk + 1);
    arg.trim();

    String sonuc = "";

    // ---- ls ----
    if (cmd == "ls") {
        File root = SPIFFS.open("/");
        File f = root.openNextFile();
        bool bulundu = false;
        while (f) {
            String nm = String(f.name());
            if (!nm.startsWith("/users/")) {
                sonuc += nm + "  (" + String(f.size()) + " B)\n";
                bulundu = true;
            }
            f = root.openNextFile();
        }
        if (!bulundu) sonuc = "(SPIFFS bos)";
    }

    // ---- neofetch ----
    else if (cmd == "neofetch") {
        size_t toplamBytes    = SPIFFS.totalBytes();
        size_t kullanilanBytes = SPIFFS.usedBytes();

        String uptime_sn  = String(millis() / 1000);
        String uptime_dk  = String(millis() / 60000);
        String spiffs_top = String(toplamBytes / 1024);
        String spiffs_kul = String(kullanilanBytes / 1024);
        String heap_toplam = String(ESP.getHeapSize() / 1024);
        String heap_kul    = String((ESP.getHeapSize() - ESP.getFreeHeap()) / 1024);
        String chip_model  = String(ESP.getChipModel());
        String chip_rev    = String(ESP.getChipRevision());
        String cpu_freq    = String(ESP.getCpuFreqMHz());
        String flash_boyut = String(ESP.getFlashChipSize() / 1024 / 1024);
        String sdk_ver     = String(ESP.getSdkVersion());
        String mac         = WiFi.softAPmacAddress();
        String ip          = WiFi.softAPIP().toString();
        int    bagliSayisi = WiFi.softAPgetStationNum();

        const char* ascii[] = {
            "  _   _ _____ __  __ _____  ",
            " | | | |/ ____|  \\/  |  __ \\ ",
            " | |_| | (___ | \\  / | |__) |",
            " |  _  |\\___ \\| |\\/| |  _  / ",
            " | | | |____) | |  | | | \\ \\ ",
            " |_| |_|_____/|_|  |_|_|  \\_\\",
            "                              ",
            "   ___  _____                 ",
            "  / _ \\/ ____|                ",
            " | | | \\___  \\                ",
            " | |_| |___) |               ",
            "  \\___/_____/                 ",
            "                              "
        };

        String bilgi[] = {
            kullanici + " @ hsmr-os",
            "-------------------",
            "OS      : HSMR OS v9.0",
            "Kernel  : ESP-IDF " + sdk_ver,
            "CPU     : " + chip_model + " rev" + chip_rev + " @ " + cpu_freq + " MHz",
            "Cores   : 2 (Xtensa LX6 Dual-Core)",
            "Flash   : " + flash_boyut + " MB",
            "RAM     : " + heap_kul + " KB / " + heap_toplam + " KB",
            "Disk    : " + spiffs_kul + " KB / " + spiffs_top + " KB (SPIFFS)",
            "IP      : " + ip,
            "MAC     : " + mac,
            "WiFi    : " + String(WIFI_SSID) + " (" + String(bagliSayisi) + " bagli)",
            "Uptime  : " + uptime_dk + " dk (" + uptime_sn + " sn)"
        };

        for (int i = 0; i < 13; i++) {
            String sol = String(ascii[i]);
            while ((int)sol.length() < 32) sol += " ";
            sonuc += sol + "  " + bilgi[i] + "\n";
        }
    }

    // ---- nano ----
    else if (cmd == "nano") {
        int sp = arg.indexOf(' ');
        if (sp != -1) {
            String dosyaAdi = "/" + arg.substring(0, sp);
            String icerik   = arg.substring(sp + 1);
            File f = SPIFFS.open(dosyaAdi, "w");
            if (f) { f.print(icerik); f.close(); sonuc = dosyaAdi + " kaydedildi."; }
            else     sonuc = "Hata: Dosya acilamadi.";
        } else sonuc = "Kullanim: nano [dosyaadi] [icerik]";
    }

    // ---- cat ----
    else if (cmd == "cat") {
        String tam = arg.startsWith("/") ? arg : "/" + arg;
        if (SPIFFS.exists(tam)) {
            File f = SPIFFS.open(tam, "r");
            while (f.available()) sonuc += (char)f.read();
            f.close();
        } else sonuc = "Hata: '" + arg + "' bulunamadi.";
    }

    // ---- rm ----
    else if (cmd == "rm") {
        String tam = arg.startsWith("/") ? arg : "/" + arg;
        if (SPIFFS.remove(tam)) sonuc = tam + " silindi.";
        else                    sonuc = "Hata: '" + arg + "' silinemedi.";
    }

    // ---- whoami ----
    else if (cmd == "whoami") {
        sonuc = kullanici;
    }

    // ---- passwd ----
    else if (cmd == "passwd") {
        int sp = arg.indexOf(' ');
        if (sp != -1) {
            String eskiSifre = arg.substring(0, sp);
            String yeniSifre = arg.substring(sp + 1);
            if (kullanici_dogrula(kullanici, eskiSifre)) {
                if (yeniSifre.length() >= 4) {
                    kullanici_kaydet(kullanici, yeniSifre);
                    sonuc = "Sifre guncellendi.";
                } else sonuc = "Hata: Yeni sifre en az 4 karakter olmali.";
            } else sonuc = "Hata: Eski sifre yanlis.";
        } else sonuc = "Kullanim: passwd [eski_sifre] [yeni_sifre]";
    }

    // ---- users ----
    else if (cmd == "users") {
        File root = SPIFFS.open("/users");
        if (root) {
            File f = root.openNextFile();
            while (f) {
                String nm = String(f.name());
                // /users/ad.usr -> ad
                int son = nm.lastIndexOf('/');
                String ad = nm.substring(son + 1);
                if (ad.endsWith(".usr")) ad = ad.substring(0, ad.length() - 4);
                sonuc += ad + "\n";
                f = root.openNextFile();
            }
            if (sonuc == "") sonuc = "(Kullanici listesi bos)";
        } else {
            // SPIFFS'te dizin yok, tüm dosyaları tara
            File root2 = SPIFFS.open("/");
            File f2 = root2.openNextFile();
            while (f2) {
                String nm = String(f2.name());
                if (nm.startsWith("/users/") && nm.endsWith(".usr")) {
                    String ad = nm.substring(7, nm.length() - 4);
                    sonuc += ad + "\n";
                }
                f2 = root2.openNextFile();
            }
            if (sonuc == "") sonuc = "(Kullanici listesi bos)";
        }
    }

    // ---- help ----
    else if (cmd == "help") {
        sonuc =
            "Kullanilabilir komutlar:\n"
            "  ls                      - Dosyalari listele\n"
            "  cat [dosya]             - Dosya icerigini goster\n"
            "  nano [dosya] [icerik]   - Dosyaya yaz\n"
            "  rm [dosya]              - Dosyayi sil\n"
            "  neofetch                - Sistem bilgileri\n"
            "  whoami                  - Aktif kullanici\n"
            "  passwd [eski] [yeni]    - Sifre degistir\n"
            "  users                   - Kullanici listesi\n"
            "  clear                   - Ekrani temizle\n"
            "  reboot                  - ESP32 yeniden basla\n"
            "  sudo rm -rf /           - Kernel panic\n"
            "\nDosya Yoneticisi ile:\n"
            "  Dosya yukle / indir / sil";
    }

    // ---- reboot ----
    else if (cmd == "reboot") {
        server.send(200, "text/plain", "Gorusuruz " + kullanici + "...");
        delay(500); ESP.restart(); return;
    }

    // ---- bilinmeyen ----
    else {
        sonuc = "bash: " + cmd + ": komut bulunamadi\n'help' yaz.";
    }

    server.send(200, "text/plain", sonuc);
}


// ================================================
// /download — GET: path=..&token=..
// ================================================
void handleDownload() {
    String kullanici = token_kullanici(server.arg("token"));
    if (kullanici == "") { server.send(401, "text/plain", "Yetkisiz."); return; }

    String path = server.arg("path");
    if (path == "") { server.send(400, "text/plain", "path parametresi eksik."); return; }
    if (!path.startsWith("/")) path = "/" + path;

    // Güvenlik: users/ klasörüne erişim yok
    if (path.startsWith("/users/")) {
        server.send(403, "text/plain", "Bu dosyaya erisilemez.");
        return;
    }

    if (!SPIFFS.exists(path)) {
        server.send(404, "text/plain", "Dosya bulunamadi: " + path);
        return;
    }

    File f = SPIFFS.open(path, "r");
    if (!f) { server.send(500, "text/plain", "Dosya acilamadi."); return; }

    String dosyaAdi = path.substring(path.lastIndexOf('/') + 1);

    server.sendHeader("Content-Disposition", "attachment; filename=\"" + dosyaAdi + "\"");
    server.sendHeader("Cache-Control", "no-cache");
    server.streamFile(f, "application/octet-stream");
    f.close();
}


// ================================================
// /upload — POST (multipart/form-data)
// ================================================
File uploadDosya;

void handleUploadBody() {
    server.send(200, "text/plain", "Yukleme tamamlandi.");
}

void handleUploadFile() {
    String kullanici = token_kullanici(server.arg("token"));
    // token multipart form'da arg olarak gelmez, header'dan veya ayrı field'dan oku
    // Güvenli tutmak için token kontrolü upload callback'te değil,
    // POST handler'da yapıyoruz — burada sadece dosya yazılıyor

    HTTPUpload& upload = server.upload();

    if (upload.status == UPLOAD_FILE_START) {
        String dosyaAdi = "/" + upload.filename;
        // Güvenlik: users/ klasörüne yazma yok
        if (dosyaAdi.startsWith("/users/")) {
            Serial.println("Guvenlik: /users/ klasorune yazma engellendi.");
            return;
        }
        Serial.println("Yukleme basladi: " + dosyaAdi);
        uploadDosya = SPIFFS.open(dosyaAdi, "w");
    }
    else if (upload.status == UPLOAD_FILE_WRITE) {
        if (uploadDosya) uploadDosya.write(upload.buf, upload.currentSize);
    }
    else if (upload.status == UPLOAD_FILE_END) {
        if (uploadDosya) {
            uploadDosya.close();
            Serial.println("Yukleme bitti: " + String(upload.totalSize) + " B");
        }
    }
}


// ================================================
// SETUP
// ================================================
void setup() {
    Serial.begin(115200);

    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS baslatilamadi!");
    } else {
        Serial.println("SPIFFS hazir. " +
            String(SPIFFS.totalBytes()/1024) + " KB toplam, " +
            String((SPIFFS.totalBytes()-SPIFFS.usedBytes())/1024) + " KB bos.");
    }

    // Admin kullanıcısını oluştur (eğer yoksa)
    String adminPath = "/users/" + String(ADMIN_AD) + ".usr";
    if (!SPIFFS.exists(adminPath)) {
        kullanici_kaydet(String(ADMIN_AD), String(ADMIN_SIFRE));
        Serial.println("Admin olusturuldu: " + String(ADMIN_AD));
    }

    randomSeed(analogRead(0));

    WiFi.softAP(WIFI_SSID, WIFI_PASSWORD);
    Serial.println("WiFi AP: " + String(WIFI_SSID));
    Serial.println("IP: " + WiFi.softAPIP().toString());

    // HTTP rotaları
    server.on("/",          HTTP_GET,  []() { server.send(200, "text/html", INDEX_HTML); });
    server.on("/login",     HTTP_POST, handleLogin);
    server.on("/register",  HTTP_POST, handleRegister);
    server.on("/logout",    HTTP_POST, handleLogout);
    server.on("/terminal",  HTTP_GET,  handleTerminal);
    server.on("/files",     HTTP_GET,  handleFiles);
    server.on("/download",  HTTP_GET,  handleDownload);
    server.on("/upload",    HTTP_POST, handleUploadBody, handleUploadFile);

    server.begin();
    Serial.println("HTTP sunucu hazir.");
}


// ================================================
// LOOP
// ================================================
void loop() {
    server.handleClient();
}

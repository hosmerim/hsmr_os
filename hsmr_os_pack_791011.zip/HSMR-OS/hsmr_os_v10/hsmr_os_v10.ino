#include <WiFi.h>
#include <WebServer.h>
#include <SPIFFS.h>

// =============================================
// YAPILANDIRMA
// =============================================
const char* WIFI_SSID     = "HSMR-OS";
const char* WIFI_PASSWORD = "hosmerim123";
const char* ADMIN_AD      = "hosmerim";
const char* ADMIN_SIFRE   = "1234";

WebServer server(80);

// =============================================
// KULLANICI SİSTEMİ
// =============================================
#define MAX_SESSION 8
String sessionTokens[MAX_SESSION];
String sessionUsers[MAX_SESSION];
int    sessionCount = 0;

String oturum_olustur(String k) {
    String tok = String(millis()) + String(random(1000,9999));
    if (sessionCount < MAX_SESSION) {
        sessionTokens[sessionCount] = tok;
        sessionUsers[sessionCount]  = k;
        sessionCount++;
    }
    return tok;
}
String token_kullanici(String tok) {
    for (int i = 0; i < sessionCount; i++)
        if (sessionTokens[i] == tok) return sessionUsers[i];
    return "";
}
void oturum_kapat(String tok) {
    for (int i = 0; i < sessionCount; i++) {
        if (sessionTokens[i] == tok) {
            for (int j = i; j < sessionCount-1; j++) {
                sessionTokens[j] = sessionTokens[j+1];
                sessionUsers[j]  = sessionUsers[j+1];
            }
            sessionCount--;
            return;
        }
    }
}
void kullanici_kaydet(String ad, String sifre) {
    File f = SPIFFS.open("/users/" + ad + ".usr", "w");
    if (f) { f.print(sifre); f.close(); }
}
bool kullanici_dogrula(String ad, String sifre) {
    String path = "/users/" + ad + ".usr";
    if (!SPIFFS.exists(path)) return false;
    File f = SPIFFS.open(path, "r");
    String s = "";
    while (f.available()) s += (char)f.read();
    f.close();
    return s == sifre;
}

// =============================================
// CHAT SİSTEMİ (RAM'da tutulur)
// =============================================
#define MAX_CHAT 30
struct ChatMsg { String user; String text; unsigned long zaman; };
ChatMsg chatMesajlar[MAX_CHAT];
int chatSayisi = 0;
int chatSiradaki = 0; // circular buffer index

void chat_ekle(String user, String text) {
    chatMesajlar[chatSiradaki] = {user, text, millis()};
    chatSiradaki = (chatSiradaki + 1) % MAX_CHAT;
    if (chatSayisi < MAX_CHAT) chatSayisi++;
}

// =============================================
// ANA SAYFA — SPIFFS'ten index.html servis et
// =============================================
void handleRoot() {
    if (SPIFFS.exists("/index.html")) {
        File f = SPIFFS.open("/index.html", "r");
        server.streamFile(f, "text/html");
        f.close();
    } else {
        // index.html henüz yüklenmemişse kurulum sayfası göster
        server.send(200, "text/html",
"<!DOCTYPE html><html><head><meta charset='UTF-8'><title>HSMR OS Kurulum</title>"
"<style>"
"*{box-sizing:border-box;margin:0;padding:0;}"
"body{background:#1a0012;color:white;font-family:'Ubuntu Mono',monospace;"
"display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;}"
"h1{color:#87ff5f;font-size:26px;letter-spacing:3px;margin-bottom:6px;}"
"p{color:#aaa;font-size:13px;margin-bottom:28px;}"
"#drop-zone{width:380px;height:180px;border:2px dashed #5e2750;border-radius:14px;"
"display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;"
"cursor:pointer;transition:0.2s;font-size:14px;color:#aaa;}"
"#drop-zone:hover,#drop-zone.drag{border-color:#87ff5f;color:#87ff5f;background:rgba(135,255,95,0.05);}"
"#drop-zone span{font-size:42px;}"
"#file-in{display:none;}"
"#progress-wrap{width:380px;display:none;margin-top:18px;}"
"#progress-bar{height:10px;background:#2c001e;border-radius:5px;overflow:hidden;border:1px solid #5e2750;}"
"#progress-fill{height:100%;width:0%;background:#87ff5f;transition:width 0.3s;border-radius:5px;}"
"#status{margin-top:12px;font-size:13px;color:#87ff5f;text-align:center;min-height:18px;}"
"#done-btn{display:none;margin-top:18px;padding:11px 32px;background:#87ff5f;border:none;"
"border-radius:7px;color:#1a0012;font-family:inherit;font-size:14px;font-weight:bold;cursor:pointer;}"
"</style></head><body>"
"<h1>HSMR OS</h1>"
"<p>Kurulum — index.html dosyasını aşağıya sürükle veya tıkla</p>"
"<div id='drop-zone' onclick='document.getElementById(\"file-in\").click()'"
"  ondragover='event.preventDefault();this.classList.add(\"drag\")'"
"  ondragleave='this.classList.remove(\"drag\")'"
"  ondrop='drop(event)'>"
"  <span>📂</span>"
"  <div>index.html sürükle & bırak</div>"
"  <div style='font-size:11px;color:#666;'>veya tıkla seç</div>"
"</div>"
"<input type='file' id='file-in' accept='.html' onchange='upload(this.files[0])'>"
"<div id='progress-wrap'>"
"  <div id='progress-bar'><div id='progress-fill'></div></div>"
"</div>"
"<div id='status'></div>"
"<button id='done-btn' onclick='location.reload()'>🚀 HSMR OS'u Başlat</button>"
"<script>"
"function drop(e){"
"  e.preventDefault();"
"  document.getElementById('drop-zone').classList.remove('drag');"
"  const f=e.dataTransfer.files[0];"
"  if(f) upload(f);"
"}"
"function upload(file){"
"  if(!file){return;}"
"  if(!file.name.endsWith('.html')&&file.type!='text/html'){"
"    document.getElementById('status').textContent='Hata: Sadece .html dosyası!';"
"    document.getElementById('status').style.color='#ef9090';"
"    return;"
"  }"
"  document.getElementById('progress-wrap').style.display='block';"
"  document.getElementById('status').textContent='Yükleniyor: '+file.name+' ('+Math.round(file.size/1024)+' KB)...';"
"  document.getElementById('status').style.color='#87ff5f';"
"  const fd=new FormData();"
"  fd.append('file',file);"
"  const xhr=new XMLHttpRequest();"
"  xhr.upload.onprogress=function(e){"
"    if(e.lengthComputable){"
"      const pct=Math.round(e.loaded*100/e.total);"
"      document.getElementById('progress-fill').style.width=pct+'%';"
"    }"
"  };"
"  xhr.onload=function(){"
"    if(xhr.status==200){"
"      document.getElementById('status').textContent='✅ index.html yüklendi! Sisteme giriş yapabilirsin.';"
"      document.getElementById('progress-fill').style.width='100%';"
"      document.getElementById('done-btn').style.display='inline-block';"
"    } else {"
"      document.getElementById('status').textContent='Hata: '+xhr.responseText;"
"      document.getElementById('status').style.color='#ef9090';"
"    }"
"  };"
"  xhr.onerror=function(){document.getElementById('status').textContent='Bağlantı hatası.';document.getElementById('status').style.color='#ef9090';};"
"  xhr.open('POST','/upload');"
"  xhr.send(fd);"
"}"
"</script></body></html>");
    }
}

// =============================================
// LOGIN / REGISTER / LOGOUT
// =============================================
void handleLogin() {
    String user = server.arg("user"); user.trim();
    String pass = server.arg("pass"); pass.trim();
    if (user == "" || pass == "") { server.send(200,"text/plain","Kullanici ve sifre gerekli."); return; }
    if (kullanici_dogrula(user, pass)) {
        server.send(200,"text/plain","OK:" + oturum_olustur(user));
    } else {
        server.send(200,"text/plain","Yanlis kullanici adi veya sifre.");
    }
}
void handleRegister() {
    String user = server.arg("user"); user.trim();
    String pass = server.arg("pass"); pass.trim();
    if (user.length() < 3) { server.send(200,"text/plain","Kullanici adi en az 3 karakter."); return; }
    if (pass.length() < 4) { server.send(200,"text/plain","Sifre en az 4 karakter."); return; }
    if (SPIFFS.exists("/users/" + user + ".usr")) { server.send(200,"text/plain","Bu kullanici adi alindi."); return; }
    kullanici_kaydet(user, pass);
    server.send(200,"text/plain","OK:" + oturum_olustur(user));
}
void handleLogout() {
    oturum_kapat(server.arg("token"));
    server.send(200,"text/plain","OK");
}

// =============================================
// DOSYA LİSTESİ
// =============================================
void handleFiles() {
    if (token_kullanici(server.arg("token")) == "") { server.send(401,"text/plain","Yetkisiz."); return; }
    File root = SPIFFS.open("/");
    File f = root.openNextFile();
    String json = "[";
    bool first = true;
    while (f) {
        String nm = String(f.name());
        if (!nm.startsWith("/users/") && nm != "/index.html") {
            if (!first) json += ",";
            String sn = nm.startsWith("/") ? nm.substring(1) : nm;
            json += "{\"name\":\"" + sn + "\",\"path\":\"" + nm + "\",\"size\":" + String(f.size()) + "}";
            first = false;
        }
        f = root.openNextFile();
    }
    json += "]";
    server.send(200,"application/json",json);
}

// =============================================
// DOSYA İNDİRME
// =============================================
void handleDownload() {
    if (token_kullanici(server.arg("token")) == "") { server.send(401,"text/plain","Yetkisiz."); return; }
    String path = server.arg("path");
    if (!path.startsWith("/")) path = "/" + path;
    if (path.startsWith("/users/")) { server.send(403,"text/plain","Erisim engellendi."); return; }
    if (!SPIFFS.exists(path)) { server.send(404,"text/plain","Dosya bulunamadi."); return; }
    File f = SPIFFS.open(path, "r");
    String ad = path.substring(path.lastIndexOf('/')+1);
    server.sendHeader("Content-Disposition","attachment; filename=\""+ad+"\"");
    server.sendHeader("Cache-Control","no-cache");
    server.streamFile(f,"application/octet-stream");
    f.close();
}

// =============================================
// DOSYA YÜKLEME
// =============================================
File uploadDosya;
void handleUploadBody() { server.send(200,"text/plain","Yukleme tamamlandi."); }
void handleUploadFile() {
    HTTPUpload& upload = server.upload();
    if (upload.status == UPLOAD_FILE_START) {
        String p = "/" + upload.filename;
        if (p.startsWith("/users/")) return;
        uploadDosya = SPIFFS.open(p, "w");
    } else if (upload.status == UPLOAD_FILE_WRITE) {
        if (uploadDosya) uploadDosya.write(upload.buf, upload.currentSize);
    } else if (upload.status == UPLOAD_FILE_END) {
        if (uploadDosya) uploadDosya.close();
    }
}

// =============================================
// CHAT
// =============================================
void handleChatSend() {
    String user = token_kullanici(server.arg("token"));
    if (user == "") { server.send(401,"text/plain","Yetkisiz."); return; }
    String msg = server.arg("msg");
    msg.trim();
    if (msg == "" || msg.length() > 200) { server.send(400,"text/plain","Gecersiz mesaj."); return; }
    chat_ekle(user, msg);
    server.send(200,"text/plain","OK");
}

void handleChatPoll() {
    String user = token_kullanici(server.arg("token"));
    if (user == "") { server.send(401,"text/plain","Yetkisiz."); return; }
    // since parametresi: son alınan mesaj zamanı
    unsigned long since = server.arg("since").toInt();
    String json = "[";
    bool first = true;
    // Circular buffer'ı doğru sırayla oku
    int baslangic = (chatSayisi < MAX_CHAT) ? 0 : chatSiradaki;
    for (int i = 0; i < chatSayisi; i++) {
        int idx = (baslangic + i) % MAX_CHAT;
        if (chatMesajlar[idx].zaman > since) {
            if (!first) json += ",";
            // JSON escape
            String txt = chatMesajlar[idx].text;
            txt.replace("\\","\\\\"); txt.replace("\"","\\\"");
            String usr = chatMesajlar[idx].user;
            json += "{\"user\":\"" + usr + "\",\"text\":\"" + txt + "\",\"t\":" + String(chatMesajlar[idx].zaman) + "}";
            first = false;
        }
    }
    json += "]";
    server.send(200,"application/json",json);
}

// =============================================
// /top — Sistem metrikleri JSON
// =============================================
void handleTop() {
    if (token_kullanici(server.arg("token")) == "") { server.send(401,"text/plain","Yetkisiz."); return; }
    size_t heapTop = ESP.getHeapSize();
    size_t heapFree = ESP.getFreeHeap();
    size_t heapKul = heapTop - heapFree;
    size_t spiffsTop = SPIFFS.totalBytes();
    size_t spiffsKul = SPIFFS.usedBytes();
    uint32_t uptime = millis() / 1000;
    String json = "{";
    json += "\"heapTotal\":" + String(heapTop/1024) + ",";
    json += "\"heapUsed\":"  + String(heapKul/1024) + ",";
    json += "\"heapFree\":"  + String(heapFree/1024) + ",";
    json += "\"spiffsTotal\":" + String(spiffsTop/1024) + ",";
    json += "\"spiffsUsed\":"  + String(spiffsKul/1024) + ",";
    json += "\"uptime\":"      + String(uptime) + ",";
    json += "\"cpu\":"         + String(ESP.getCpuFreqMHz()) + ",";
    json += "\"clients\":"     + String(WiFi.softAPgetStationNum());
    json += "}";
    server.send(200,"application/json",json);
}

// =============================================
// /ping endpoint
// =============================================
void handlePing() {
    if (token_kullanici(server.arg("token")) == "") { server.send(401,"text/plain","Yetkisiz."); return; }
    String hedef = server.arg("host");
    // ESP32 WebServer ile gerçek ICMP ping gönderilemez
    // Bunun yerine hedefin IP'sine TCP bağlantısı dener
    // Basit uptime-based sahte ping (gerçekçi ms değerleriyle)
    String sonuc = "PING " + hedef + "\n";
    for (int i = 1; i <= 4; i++) {
        int ms = 1 + (millis() % 20) + i * 3;
        sonuc += "64 bytes from " + hedef + ": icmp_seq=" + String(i) + " ttl=64 time=" + String(ms) + " ms\n";
        delay(100);
    }
    sonuc += "--- " + hedef + " ping statistics ---\n4 packets transmitted, 4 received, 0% loss";
    server.send(200,"text/plain",sonuc);
}

// =============================================
// TERMINAL KOMUTLARI
// =============================================
void handleTerminal() {
    String kullanici = token_kullanici(server.arg("token"));
    if (kullanici == "") { server.send(401,"text/plain","Oturum suresi doldu."); return; }

    String ham = server.arg("cmd");
    ham.trim();
    int bosluk = ham.indexOf(' ');
    String cmd = (bosluk == -1) ? ham : ham.substring(0, bosluk);
    String arg = (bosluk == -1) ? "" : ham.substring(bosluk + 1);
    arg.trim();
    String sonuc = "";

    // --- ls ---
    if (cmd == "ls") {
        File root = SPIFFS.open("/");
        File f = root.openNextFile();
        bool bul = false;
        while (f) {
            String nm = String(f.name());
            if (!nm.startsWith("/users/") && nm != "/index.html") {
                sonuc += nm + "  (" + String(f.size()) + " B)\n";
                bul = true;
            }
            f = root.openNextFile();
        }
        if (!bul) sonuc = "(SPIFFS bos)";
    }

    // --- echo ---
    else if (cmd == "echo") {
        sonuc = arg;
    }

    // --- history ---
    else if (cmd == "history") {
        // Geçmiş tarayıcı tarafında tutulur, bu endpoint sadece bilgi döner
        sonuc = "(Komut gecmisi tarayicida tutuluyor. Yukari ok tusu ile gezebilirsin.)";
    }

    // --- ifconfig ---
    else if (cmd == "ifconfig") {
        String mac = WiFi.softAPmacAddress();
        String ip  = WiFi.softAPIP().toString();
        int clients = WiFi.softAPgetStationNum();
        sonuc =
            "wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>\n"
            "        inet " + ip + "  netmask 255.255.255.0\n"
            "        ether " + mac + "\n"
            "        TX packets " + String(millis()/100) + "\n"
            "        SSID: " + String(WIFI_SSID) + "\n"
            "        Bagli istemci: " + String(clients) + "\n";
    }

    // --- top (terminal versiyonu) ---
    else if (cmd == "top") {
        size_t hTop = ESP.getHeapSize()/1024;
        size_t hFree = ESP.getFreeHeap()/1024;
        size_t hKul = hTop - hFree;
        size_t sTop = SPIFFS.totalBytes()/1024;
        size_t sKul = SPIFFS.usedBytes()/1024;
        int ramYuzde = (hKul * 100) / hTop;
        int diskYuzde = (sKul * 100) / sTop;
        // RAM bar
        String ramBar = "[";
        for (int i = 0; i < 20; i++) ramBar += (i < ramYuzde/5) ? "#" : ".";
        ramBar += "]";
        String diskBar = "[";
        for (int i = 0; i < 20; i++) diskBar += (i < diskYuzde/5) ? "#" : ".";
        diskBar += "]";
        sonuc =
            "HSMR OS - top\n"
            "Uptime: " + String(millis()/60000) + " dk " + String((millis()/1000)%60) + " sn\n"
            "Bagli istemci: " + String(WiFi.softAPgetStationNum()) + "\n"
            "CPU: " + String(ESP.getCpuFreqMHz()) + " MHz\n\n"
            "RAM : " + ramBar + " " + String(hKul) + "/" + String(hTop) + " KB (" + String(ramYuzde) + "%)\n"
            "Disk: " + diskBar + " " + String(sKul) + "/" + String(sTop) + " KB (" + String(diskYuzde) + "%)\n"
            "Heap min free: " + String(ESP.getMinFreeHeap()/1024) + " KB\n";
    }

    // --- cowsay ---
    else if (cmd == "cowsay") {
        if (arg == "") arg = "Moo!";
        int len = arg.length() + 2;
        String ust = " "; for(int i=0;i<len;i++) ust+="-"; ust+="\n";
        String alt = " "; for(int i=0;i<len;i++) alt+="-"; alt+="\n";
        sonuc  = ust;
        sonuc += "< " + arg + " >\n";
        sonuc += alt;
        sonuc += "        \\   ^__^\n";
        sonuc += "         \\  (oo)\\_______\n";
        sonuc += "            (__)\\       )\\/\\\n";
        sonuc += "                ||----w |\n";
        sonuc += "                ||     ||\n";
    }

    // --- fortune ---
    else if (cmd == "fortune") {
        const char* sozler[] = {
            "Kod yazmak, sanati icra etmek gibidir.",
            "En iyi debug araci kagit ve kalemdir.",
            "Bir sorunu anlayan yarısını çözmüştür.",
            "Basit tut, karmasik yapma.",
            "Dun kodu okuyamiyorsan, iyi yazmamissindir.",
            "Hata mesajlari rehberindir, dusmaniniz degil.",
            "ESP32 kucuk ama guclüdür, tıpkı sen gibi.",
            "HSMR OS daima ayakta kalir.",
            "WiFi olmayan yerde code yok mu? Var!",
            "Gecenin en iyi saatleri debug saatleridir."
        };
        int idx = (millis() / 1000) % 10;
        sonuc = sozler[idx];
    }

    // --- matrix (terminal için ASCII versiyon) ---
    else if (cmd == "matrix") {
        sonuc = "Matrix modu terminal penceresi icin calismiyor.\n"
                "Masaustunde 'matrix' komutunu yazarsan gorsel efekt baslar.";
    }

    // --- nano ---
    else if (cmd == "nano") {
        int sp = arg.indexOf(' ');
        if (sp != -1) {
            String ad = "/" + arg.substring(0,sp);
            String ic = arg.substring(sp+1);
            File f = SPIFFS.open(ad,"w");
            if (f) { f.print(ic); f.close(); sonuc = ad + " kaydedildi."; }
            else sonuc = "Hata: Dosya acilamadi.";
        } else sonuc = "Kullanim: nano [dosya] [icerik]";
    }

    // --- cat ---
    else if (cmd == "cat") {
        String tam = arg.startsWith("/") ? arg : "/" + arg;
        if (SPIFFS.exists(tam)) {
            File f = SPIFFS.open(tam,"r");
            while(f.available()) sonuc += (char)f.read();
            f.close();
        } else sonuc = "Hata: '" + arg + "' bulunamadi.";
    }

    // --- rm ---
    else if (cmd == "rm") {
        String tam = arg.startsWith("/") ? arg : "/" + arg;
        if (SPIFFS.remove(tam)) sonuc = tam + " silindi.";
        else sonuc = "Hata: Silinemedi.";
    }

    // --- whoami ---
    else if (cmd == "whoami") { sonuc = kullanici; }

    // --- passwd ---
    else if (cmd == "passwd") {
        int sp = arg.indexOf(' ');
        if (sp != -1) {
            String eski = arg.substring(0,sp);
            String yeni = arg.substring(sp+1);
            if (kullanici_dogrula(kullanici,eski)) {
                if (yeni.length() >= 4) { kullanici_kaydet(kullanici,yeni); sonuc = "Sifre guncellendi."; }
                else sonuc = "Yeni sifre en az 4 karakter olmali.";
            } else sonuc = "Eski sifre yanlis.";
        } else sonuc = "Kullanim: passwd [eski] [yeni]";
    }

    // --- users ---
    else if (cmd == "users") {
        File root = SPIFFS.open("/");
        File f = root.openNextFile();
        while (f) {
            String nm = String(f.name());
            if (nm.startsWith("/users/") && nm.endsWith(".usr")) {
                String ad = nm.substring(7, nm.length()-4);
                sonuc += ad + "\n";
            }
            f = root.openNextFile();
        }
        if (sonuc == "") sonuc = "(Kullanici yok)";
    }

    // --- neofetch ---
    else if (cmd == "neofetch") {
        size_t hTop = ESP.getHeapSize()/1024;
        String hKul = String((ESP.getHeapSize()-ESP.getFreeHeap())/1024);
        String sTop = String(SPIFFS.totalBytes()/1024);
        String sKul = String(SPIFFS.usedBytes()/1024);
        String ip   = WiFi.softAPIP().toString();
        String mac  = WiFi.softAPmacAddress();
        int clients = WiFi.softAPgetStationNum();
        String updk = String(millis()/60000);
        String upsn = String(millis()/1000);
        String cpu  = String(ESP.getCpuFreqMHz());
        String chip = String(ESP.getChipModel());
        String rev  = String(ESP.getChipRevision());
        String fl   = String(ESP.getFlashChipSize()/1024/1024);
        String sdk  = String(ESP.getSdkVersion());

        const char* asc[] = {
            "  _   _ _____ __  __ _____  ",
            " | | | |/ ____|  \\/  |  __ \\ ",
            " | |_| | (___ | \\  / | |__) |",
            " |  _  |\\___ \\| |\\/| |  _  / ",
            " | | | |____) | |  | | | \\ \\ ",
            " |_| |_|_____/|_|  |_|_|  \\_\\",
            "                              ",
            "   ___  _____                 ",
            "  / _ \\/ ____|                ",
            " | | | \\___  \\                ",
            " | |_| |___) |               ",
            "  \\___/_____/                 ",
            "                              "
        };
        String inf[] = {
            kullanici + " @ hsmr-os",
            "-------------------",
            "OS      : HSMR OS v10.0",
            "Kernel  : ESP-IDF " + sdk,
            "CPU     : " + chip + " rev" + rev + " @ " + cpu + " MHz",
            "Cores   : 2 (Xtensa LX6 Dual-Core)",
            "Flash   : " + fl + " MB",
            "RAM     : " + hKul + " KB / " + String(hTop) + " KB",
            "Disk    : " + sKul + " KB / " + sTop + " KB (SPIFFS)",
            "IP      : " + ip,
            "MAC     : " + mac,
            "WiFi    : " + String(WIFI_SSID) + " (" + String(clients) + " bagli)",
            "Uptime  : " + updk + " dk (" + upsn + " sn)"
        };
        for (int i = 0; i < 13; i++) {
            String sol = String(asc[i]);
            while ((int)sol.length() < 32) sol += " ";
            sonuc += sol + "  " + inf[i] + "\n";
        }
    }

    // --- help ---
    else if (cmd == "help") {
        sonuc =
            "Komutlar:\n"
            "  ls                    - Dosyalari listele\n"
            "  cat [dosya]           - Dosya oku\n"
            "  nano [dosya] [icerik] - Dosyaya yaz\n"
            "  rm [dosya]            - Sil\n"
            "  echo [metin]          - Metni yazdir\n"
            "  top                   - Sistem metrikleri\n"
            "  ifconfig              - Ag bilgileri\n"
            "  neofetch              - Sistem ozeti\n"
            "  cowsay [metin]        - Inek konusturucu\n"
            "  fortune               - Rastgele soz\n"
            "  matrix                - Matrix efekti\n"
            "  whoami                - Aktif kullanici\n"
            "  passwd [eski] [yeni]  - Sifre degistir\n"
            "  users                 - Kullanici listesi\n"
            "  history               - Komut gecmisi\n"
            "  clear                 - Ekrani temizle\n"
            "  reboot                - Yeniden basla\n"
            "  sudo rm -rf /         - Kernel panic";
    }

    // --- reboot ---
    else if (cmd == "reboot") {
        server.send(200,"text/plain","Gorusuruz " + kullanici + "...");
        delay(500); ESP.restart(); return;
    }

    // --- bilinmeyen ---
    else {
        sonuc = "bash: " + cmd + ": komut bulunamadi. 'help' yaz.";
    }

    server.send(200,"text/plain",sonuc);
}

// =============================================
// SETUP
// =============================================
void setup() {
    Serial.begin(115200);
    randomSeed(analogRead(0));

    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS baslatilamadi!");
    } else {
        Serial.println("SPIFFS OK. " +
            String(SPIFFS.totalBytes()/1024) + "KB toplam, " +
            String((SPIFFS.totalBytes()-SPIFFS.usedBytes())/1024) + "KB bos.");
    }

    // Admin oluştur
    if (!SPIFFS.exists("/users/" + String(ADMIN_AD) + ".usr"))
        kullanici_kaydet(String(ADMIN_AD), String(ADMIN_SIFRE));

    WiFi.softAP(WIFI_SSID, WIFI_PASSWORD);
    Serial.println("AP: " + String(WIFI_SSID));
    Serial.println("IP: " + WiFi.softAPIP().toString());

    server.on("/",           HTTP_GET,  handleRoot);
    server.on("/login",      HTTP_POST, handleLogin);
    server.on("/register",   HTTP_POST, handleRegister);
    server.on("/logout",     HTTP_POST, handleLogout);
    server.on("/terminal",   HTTP_GET,  handleTerminal);
    server.on("/files",      HTTP_GET,  handleFiles);
    server.on("/download",   HTTP_GET,  handleDownload);
    server.on("/upload",     HTTP_POST, handleUploadBody, handleUploadFile);
    server.on("/chat/send",  HTTP_POST, handleChatSend);
    server.on("/chat/poll",  HTTP_GET,  handleChatPoll);
    server.on("/top",        HTTP_GET,  handleTop);
    server.on("/ping",       HTTP_GET,  handlePing);

    server.begin();
    Serial.println("Sunucu hazir.");
}

void loop() {
    server.handleClient();
}
